<!DOCTYPE html>
<html>
<head>
    <title>TIME</title>
    <link rel="stylesheet" href="clock.css">
</head>
	<body>
<div> 
<nav class= "nav">
      <ul>
        <li><a href="lab2.php">lab 2 </a> </li>
        <li><a href="lab3.php">lab 3 </a></li>
        <li><a href="lab4.php">lab 4</a></li>
        <li><a href="clock.php">clock</a></li>
      </ul>
    </nav>
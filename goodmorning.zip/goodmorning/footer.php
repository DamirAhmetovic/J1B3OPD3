<!DOCTYPE html>
<html>
<head>
    <title>TIME</title>
    <link rel="stylesheet" href="clock.css">
</head>
	<body>
		<div class ="footer"><p>@ 2019-Damir Ahmetovic</p></div>
	</body>